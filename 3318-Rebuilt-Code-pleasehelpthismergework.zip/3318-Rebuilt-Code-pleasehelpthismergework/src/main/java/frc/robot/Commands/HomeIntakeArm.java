package frc.robot.Commands;

import frc.robot.subsystems.Intake;

import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkClosedLoopController;
import com.revrobotics.spark.SparkBase.ControlType;

import edu.wpi.first.wpilibj2.command.Command;

public class HomeIntakeArm extends Command {
    private final Intake intakeSubsystem;
    private final SparkClosedLoopController pidController;  
    private final RelativeEncoder encoder;  

    public HomeIntakeArm(Intake intakeSubsystem) {
        this.intakeSubsystem = intakeSubsystem;
        this.pidController = intakeSubsystem.getPIDController();
        this.encoder = intakeSubsystem.getEncoder();

        addRequirements(intakeSubsystem);
    }

    @Override
    public void execute() {
        //start moving to the up (home) position
        pidController.setSetpoint(intakeSubsystem.getArmDownPos(), ControlType.kPosition);    
    }

    @Override
    public boolean isFinished() {
        //continuously check if it has reached the up position (fault tolerance of 0.05)
        return Math.abs(encoder.getPosition() - intakeSubsystem.getArmDownPos()) < 0.05;
    }

    @Override
    public void end(boolean interrupted) {
        //once isFinished returns true, home it.
        encoder.setPosition(0);
    }
}