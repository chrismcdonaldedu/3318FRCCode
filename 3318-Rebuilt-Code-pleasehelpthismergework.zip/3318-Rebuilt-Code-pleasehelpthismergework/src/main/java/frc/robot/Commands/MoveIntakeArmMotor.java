package frc.robot.Commands;

import frc.robot.subsystems.Intake;

import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkClosedLoopController;
import com.revrobotics.spark.SparkBase.ControlType;

import edu.wpi.first.wpilibj2.command.Command;

public class MoveIntakeArmMotor extends Command {
    private final Intake intakeSubsystem;
    private final SparkClosedLoopController pidController;  
    private final RelativeEncoder encoder;  


    private boolean armWasUp;

    public MoveIntakeArmMotor(Intake intakeSubsystem) {
        this.intakeSubsystem = intakeSubsystem;
        this.pidController = intakeSubsystem.getPIDController();
        this.encoder = intakeSubsystem.getEncoder();

        addRequirements(intakeSubsystem);
    }

    @Override
    public void initialize() {
        //start moving to the up or down position based on if it's currently up or down
        if (intakeSubsystem.isArmUp()) {
            armWasUp = true;
            pidController.setSetpoint(intakeSubsystem.getArmDownPos(), ControlType.kPosition);
        } else {
            armWasUp = false;
            pidController.setSetpoint(intakeSubsystem.getArmUpPos(), ControlType.kPosition);
        }
    }

    @Override
    public void execute() {}

    @Override
    public boolean isFinished() {
        //continuously check if it has reached the up/down position (fault tolerance of 0.05)
        if(armWasUp){
            return Math.abs(encoder.getPosition() - intakeSubsystem.getArmDownPos()) < 0.05;
        }else{
            return Math.abs(encoder.getPosition() - intakeSubsystem.getArmUpPos()) < 0.05;
        }
        
    }

    @Override
    public void end(boolean interrupted) {
        //After it moves to the right position
        System.out.println("Finished moving intake arm to " + (armWasUp?"down position.":"up position."));
        intakeSubsystem.stop();
        intakeSubsystem.stopWheel();
    }
}