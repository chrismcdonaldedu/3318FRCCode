package frc.robot.Commands;

import frc.robot.subsystems.Climber;
import edu.wpi.first.wpilibj2.command.Command;

public class SpinClimbMotor extends Command {
    private final Climber climberSubsystem;
    private final double speedPercentage;

    public SpinClimbMotor(Climber climberSubsystem, double speedPercentage) {
        this.climberSubsystem = climberSubsystem;
        this.speedPercentage = speedPercentage;
        addRequirements(this.climberSubsystem);
    }

    @Override
    public void execute() {
        climberSubsystem.setPercentageSpeed(speedPercentage);
    }

    @Override
    public void end(boolean interrupted) {
        climberSubsystem.stop();
    }

    @Override
    public boolean isFinished() {
        return false;
    }
}
